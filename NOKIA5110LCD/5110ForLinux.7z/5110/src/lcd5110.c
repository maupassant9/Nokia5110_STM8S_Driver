/*
* lcd_draw.c: 
* Author: Dong Xia
* Basic draw function for mono-lcd.
*
* Change Records:
*      >> (29/08/2020): file created
*
*/

/********************************************
* Include 
********************************************/
#include "xg.h"
#include "lcd5110.h"
#include <linux/gpio.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

/********************************************
* Internal Function Declaration 
********************************************/
#define ASSERT(str, cond) do{\
	if((cond) < 0){\
		int errnum = errno;\
		perror(str);\
		return -1;\
	}\
}while(0)


#define RES(l, v) lcdSetGPIO(l, l->LCD_RST, v)
#define DC(l, v) lcdSetGPIO(l, l->LCD_DC, v)
#define BKLED(l, v) lcdSetGPIO(l, l->LCD_BKLIGHT, v)

/********************************************
* Internal Types and Variables 
********************************************/

/********************************************
* External Variables 
********************************************/


/********************************************
* Functions 
*********************************************/
static int lcdGPIOInit(lcd_ctr_t * lcd);
static int lcdSPIInit(lcd_ctr_t * lcd);
static void lcd5110SetXy(lcd_ctr_t *lcd, unsigned char X,unsigned char Y);
static int lcd5110WriteBytes(lcd_ctr_t * lcd, unsigned char *dt, size_t sz);
static void lcd5110WriteByte(lcd_ctr_t *lcd, unsigned char dt, unsigned char command);
static int lcdSetGPIO(lcd_ctr_t *lcd, unsigned int pin, unsigned int val);
static void lcd5110SetAddrMode(lcd_ctr_t * lcd, unsigned char verticalMode);
///////////////////////
//   Pin Fuctions    //
///////////////////////
static int lcdSetGPIO(lcd_ctr_t *lcd, unsigned int pin, unsigned int val)
{
	lcd->data.values[pin] = val;
	int ret = ioctl(lcd->gpio_req.fd, GPIOHANDLE_SET_LINE_VALUES_IOCTL, &lcd->data);
	if(ret < 0){
		perror(strerror(errno));
		return -1;
	}
	return 0;
}

static int lcdGPIOInit(lcd_ctr_t * lcd)
{
	int devid;
	ASSERT("[lcd_gpio - open]",devid = open(LCD5110_GPIO_DEV_PATH, O_RDONLY));
	lcd->gpio_req.flags = GPIOHANDLE_REQUEST_OUTPUT;
	lcd->gpio_req.lines = 3;
	lcd->LCD_DC = 0;
	lcd->LCD_RST = 1;
	lcd->LCD_BKLIGHT = 2;

	lcd->gpio_req.lineoffsets[lcd->LCD_DC] = LCD5110_DC_PIN;
	lcd->gpio_req.lineoffsets[lcd->LCD_RST] =  LCD5110_RESET_PIN;
	lcd->gpio_req.lineoffsets[lcd->LCD_BKLIGHT] = LCD5110_LED_PIN;
	lcd->gpio_req.default_values[lcd->LCD_DC] = 0;
	lcd->gpio_req.default_values[lcd->LCD_RST] = 0;
	lcd->gpio_req.default_values[lcd->LCD_BKLIGHT] = 0;

	int res;
	ASSERT("[lcd_gpio - ioctl]", res = ioctl(devid, GPIO_GET_LINEHANDLE_IOCTL, &lcd->gpio_req));
	close(devid);

	return 0;
}

static int lcdSPIInit(lcd_ctr_t * lcd)
{
	int fd;
	ASSERT("[lcdSPI - open]", fd = open(LCD5110_SPI_DEV_PATH, O_RDWR));
	lcd->spiid = fd;
	return 0;
}

/*------------------------------------------------ 
* lcd5110Init 
* Init the 5110 LCD
* Paras:
*  >> : 
*  >> : 
* Return: 
*  >> 
* Change Records: 
*  >> (29/08/2020): Create the function 
*----------------------------------------------*/
int lcd5110Init(lcd_ctr_t *lcd)
{
	memset(lcd, 0, sizeof(lcd_ctr_t));
	ASSERT("[lcd - init]", lcdGPIOInit(lcd));
	ASSERT("[lcd - init]", lcdSPIInit(lcd));
	//sce1();
	RES(lcd, 1);
	usleep(100000);
	RES(lcd, 0);
	usleep(100000);
	RES(lcd, 1);
	
	lcd5110SetBias(lcd, 0);
	lcd5110SetContrast(lcd, 0x40);
		
	//lcd5110WriteByte(lcd, PCD8544_FUNCTIONSET,0);
	//lcd5110WriteByte(lcd, 0x0C,0);
	lcd5110WriteByte(lcd, PCD8544_DISPLAYCONTROL | PCD8544_DISPLAYNORMAL ,0);
	//sce1();
	BKLED(lcd, 1);
}

/*------------------------------------------------ 
* lcd5110WriteByte
* Write a byte into lcd, command or data. 
* Paras:
*  >> : 
*  >> : 
* Return: 
*  >> 
* Change Records: 
*  >> (29/08/2020): Create the function 
*----------------------------------------------*/
static void lcd5110WriteByte(lcd_ctr_t *lcd, unsigned char dt, unsigned char data)
{
	if(data)
		DC(lcd, 1);
	else
		DC(lcd, 0);		
	lcd5110WriteBytes(lcd, &dt, 1);
}

static int lcd5110WriteBytes(lcd_ctr_t * lcd, unsigned char *dt, size_t sz)
{
	memset(&lcd->xfer, 0, sizeof(lcd->xfer));
	lcd->xfer.tx_buf = (unsigned long long)dt;
	lcd->xfer.len = sz;
	lcd->xfer.tx_nbits = 8;
	lcd->xfer.speed_hz = 500000;

	int ret;
	DC(lcd, 1);
	ASSERT("[lcdSPI - ioctl]",ret = ioctl(lcd->spiid, SPI_IOC_MESSAGE(sz), &lcd->xfer));
	DC(lcd, 0);
}

/*------------------------------------------------ 
* lcd5110Update
* Update the lcd 5110 screen. 
* Paras:
*  >> : 
*  >> : 
* Return: 
*  >> 
* Change Records: 
*  >> (29/08/2020): Create the function 
*----------------------------------------------*/
// void lcd5110Update(lcd_ctr_t *lcd){
// 	uint8_t x, y;
// 	uint16_t offset;

// 	for(y = 0; y < LCD_Y_RES/8; y++){
// 		lcd5110SetXy(lcd, 0,y);
// 		//offset = y * LCD_X_RES;
// 		lcd5110WriteBytes(lcd, &(lcd->lcdCache[0][y]), LCD_X_RES);
// 	}
// }
void lcd5110Update(lcd_ctr_t *lcd ){
	uint8_t x, y;
	uint8_t * data = &(lcd->lcdCache[0][0]);
	lcd5110SetXy(lcd, 0,0);
	lcd5110SetAddrMode(lcd, 1);
	lcd5110WriteBytes(lcd,data,LCD_X_RES*LCD_Y_RES/8);
	// for(y = 0; y < LCD_Y_RES/8; y++){
	// 	lcd5110SetXy(lcd, 0,y);
	// 	lcd5110WriteBytes(lcd, data[0][y], y);
	// 	// for(x = 0; x < LCD_X_RES ; x++){
	// 	// 	//lcd5110SetXy(x,y);
	// 	// 	lcd5110WriteByte(lcd, data[x*(LCD_Y_RES/8)+y], 1);
	// 	// }
	// }

}

/*------------------------------------------------ 
* Lcd5110SetXy 
* Set the origin of lcd. 
* Paras:
*  >> : 
*  >> : 
* Return: 
*  >> 
* Change Records: 
*  >> (29/08/2020): Create the function 
*----------------------------------------------*/
static void lcd5110SetXy(lcd_ctr_t *lcd, unsigned char X,unsigned char Y)
{
	lcd5110WriteByte(lcd, PCD8544_SETYADDR | Y, 0);// column
	lcd5110WriteByte(lcd, PCD8544_SETXADDR | X, 0);// row
}


void lcd5110SetBias(lcd_ctr_t * lcd, unsigned char val)
{
	if (val > 0x07) {
		val = 0x07;
	}
	lcd5110WriteByte(lcd, PCD8544_FUNCTIONSET | PCD8544_EXTENDEDINSTRUCTION,0);
	lcd5110WriteByte(lcd, PCD8544_SETBIAS | val, 0);
	lcd5110WriteByte(lcd, PCD8544_FUNCTIONSET, 0);
}


void lcd5110SetContrast(lcd_ctr_t * lcd, unsigned char val)
{
	if(val > 0x7f) val = 0x7f;
	lcd5110WriteByte(lcd, PCD8544_FUNCTIONSET | PCD8544_EXTENDEDINSTRUCTION, 0);
	lcd5110WriteByte(lcd, PCD8544_SETVOP | val, 0);
	lcd5110WriteByte(lcd, PCD8544_FUNCTIONSET, 0);
}


static void lcd5110SetAddrMode(lcd_ctr_t * lcd, unsigned char verticalMode)
{
	unsigned char cmd = PCD8544_FUNCTIONSET;
	if(verticalMode) cmd |= PCD8544_VERTICAL_MODE;
	lcd5110WriteByte(lcd, cmd, 0);
}