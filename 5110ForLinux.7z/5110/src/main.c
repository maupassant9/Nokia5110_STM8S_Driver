#include "lcd_draw.h"
#include "lcd5110.h"
#include "xg.h"

lcd_ctr_t lcd;
int main()
{
    if(lcd5110Init(&lcd))
    {
        return -1;
    }
    LcdClear(&lcd);
    LcdDrawHLine(&lcd, 2, 2, 100, LCD_DRAW_MODE_SET);
    LcdPutInteger(&lcd, 5, 6, 123, LCD_DRAW_MODE_SET);
    lcd5110Update(&lcd);
    return 0;
}