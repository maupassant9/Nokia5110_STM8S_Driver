#include <linux/gpio.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fid = open("/dev/gpiochip0", O_RDONLY);
    if(fid < 0)
    {
        perror("open");
        return -1;
    }
    struct gpiohandle_request gpiohandle = {
        .lines = 1,
        .lineoffsets = {131},
        .flags = GPIOHANDLE_REQUEST_OUTPUT,
        .default_values = {0}
    };
    int ret = ioctl(fid, GPIO_GET_LINEHANDLE_IOCTL, &gpiohandle);
    if(ret < 0){
        perror("ioctl");
        return -1;
    }
    close(fid);
    struct gpiohandle_data data;
    for(int i = 0; i < 100; i++){
        data.values[0] = i%2;
	    ret = ioctl(gpiohandle.fd, GPIOHANDLE_SET_LINE_VALUES_IOCTL, &data);
	    if(ret < 0){
		    perror("gpio");
		    return -1;
	    }
        usleep(100000);
    }

}