

#ifndef __FONT__H__
#define __FONT__H__


typedef struct _font_t{
   const unsigned char * font;
   unsigned int width;
   unsigned int height;
   unsigned char size_in_byte;
}font_t;

extern font_t font_6x8_;
extern font_t font_4x6_;

#endif