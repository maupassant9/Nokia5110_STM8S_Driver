#include <stdio.h>
#include "lcd_draw.h"
#include "lcd5110.h"
#include "xg.h"

lcd_ctr_t lcd;
int main()
{
    if(lcd5110Init(&lcd))
    {
        printf("Error in init!\n");
        return -1;
    }
    LcdClear(&lcd);
    LcdSetFont(&lcd, &font_4x6_);
    LcdPutStringWrap(&lcd, 0, 0, "What's your opinion? You want to do something about it? Ok, let's do it! Wonderful, what can I do it. The best thing of the right thing to do is to do something wrong.", LCD_DRAW_MODE_SET);
    LcdPutInteger(&lcd, 30,40, 1234, LCD_DRAW_MODE_SET);
    //LcdDrawHLine(&lcd, 20,20,10,LCD_DRAW_MODE_SET);
    lcd5110Update(&lcd);
    return 0;
}