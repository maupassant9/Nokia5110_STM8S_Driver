/* 
* lcd_draw.h 
* Author: Dong Xia 
* LCD Basic Draw functions
* 
* Change Records: 
*      >> (29/08/2020): Creation of file 
* 
*/

#ifndef  _LCD_DRAW_H_
#define  _LCD_DRAW_H_
/********************************************
* Include 
********************************************/
#include "xg.h"
#include "lcd5110.h"
//#define LCD_Y_RES 48
//#define LCD_X_RES 84
/********************************************
* Macro 
********************************************/

/********************************************
* Type definition 
********************************************/

typedef enum{
	LCD_DRAW_MODE_SET = 0,
	LCD_DRAW_MODE_CLR,
	LCD_DRAW_MODE_XOR	
}lcd_draw_mode_t;

/********************************************
* Function prototype 
********************************************/
void LcdClear(lcd_ctr_t *lcd);
void LcdDrawPixel(lcd_ctr_t *lcd, unsigned char x, unsigned char y, lcd_draw_mode_t mode);
void LcdDrawLine(lcd_ctr_t *lcd, uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, lcd_draw_mode_t mode);
void LcdDrawCircle(lcd_ctr_t *lcd, uint8_t x, uint8_t y, uint8_t radius, lcd_draw_mode_t mode);
void LcdDrawVLine(lcd_ctr_t *lcd, uint8_t x, uint8_t y,uint8_t l, lcd_draw_mode_t mode);
void LcdDrawHLine(lcd_ctr_t *lcd, uint8_t x, uint8_t y, 
		uint8_t len, lcd_draw_mode_t mode);
void LcdDrawRect(lcd_ctr_t *lcd, uint8_t x1,uint8_t y1, 
		uint8_t x2, uint8_t y2,
		lcd_draw_mode_t mode);
void LcdDrawRoundRect(lcd_ctr_t *lcd, uint8_t x1, uint8_t y1,
			uint8_t x2, uint8_t y2,	
			uint8_t r, lcd_draw_mode_t mode);
void LcdDrawBitmap(lcd_ctr_t *lcd, uint8_t x, uint8_t y, 
		uint8_t * bitmap, 
		uint8_t sx,uint8_t sy,
		lcd_draw_mode_t mode);
void LcdPutOneNumber(lcd_ctr_t *lcd, uint8_t x, uint8_t y, 
			uint8_t num, lcd_draw_mode_t mode);
void LcdPutInteger(lcd_ctr_t *lcd, uint8_t x, uint8_t y, 
		uint32_t num, lcd_draw_mode_t mode);
void LcdPutChar(lcd_ctr_t *lcd, uint8_t x, uint8_t y, uint8_t c, lcd_draw_mode_t mode);
void LcdPutString(lcd_ctr_t *lcd, uint8_t x,uint8_t y,char *s, lcd_draw_mode_t mode);

void LcdFillRect(lcd_ctr_t *lcd, uint8_t x1, uint8_t y1, 
		uint8_t x2, uint8_t y2,
		lcd_draw_mode_t mode);
void LcdDrawCircleHelper(lcd_ctr_t *lcd, uint8_t x0, uint8_t y0, uint8_t r,
			uint8_t corners, lcd_draw_mode_t mode);
void LcdFillCircle(lcd_ctr_t *lcd, uint8_t x0, uint8_t y0, uint8_t r,
                   lcd_draw_mode_t mode);
void LcdFillCircleHelper(lcd_ctr_t *lcd, uint8_t x0, uint8_t y0, uint8_t r,
                         uint8_t corners, uint8_t delta,
                          lcd_draw_mode_t mode);
void LcdDrawTriangle(lcd_ctr_t *lcd, uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1,
                     uint8_t x2, uint8_t y2, lcd_draw_mode_t mode);
void LcdFillTriangle(lcd_ctr_t *lcd, uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1,
                      uint8_t x2, uint8_t y2, lcd_draw_mode_t mode);
void LcdFillRoundRect(lcd_ctr_t *lcd, uint8_t x1, uint8_t y1,
			uint8_t x2, uint8_t y2,
			uint8_t r, lcd_draw_mode_t mode);
void LcdPutStringWrap(lcd_ctr_t *lcd, uint8_t x,uint8_t y,char *s, lcd_draw_mode_t mode);
void LcdSetFont(lcd_ctr_t *l, font_t *f);
#endif
