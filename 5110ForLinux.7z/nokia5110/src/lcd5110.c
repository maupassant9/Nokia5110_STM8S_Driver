/*
* lcd_draw.c: 
* Author: Dong Xia
* Basic draw function for mono-lcd.
*
* Change Records:
*      >> (29/08/2020): file created
*
*/

/********************************************
* Include 
********************************************/
#include "xg.h"
#include "lcd5110.h"
#include <linux/gpio.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

/********************************************
* Internal Function Declaration 
********************************************/
#define ASSERT(str, cond) do{\
	if((cond) < 0){\
		int errnum = errno;\
		perror(str);\
		return -1;\
	}\
}while(0)


#define RES(l, v) lcdSetGPIO(l, l->LCD_RST, v)
#define DC(l, v) lcdSetGPIO(l, l->LCD_DC, v)
//#define BKLED(l, v) lcdSetGPIO(l, l->LCD_BKLIGHT, v)

/********************************************
* Internal Types and Variables 
********************************************/

/********************************************
* External Variables 
********************************************/


/********************************************
* Functions 
*********************************************/
static int lcdGPIOInit(lcd_ctr_t * lcd);
static int lcdSPIInit(lcd_ctr_t * lcd);
static void lcd5110SetXy(lcd_ctr_t *lcd, unsigned char X,unsigned char Y);
static int lcd5110WriteDatasRaw(lcd_ctr_t * lcd, unsigned char *dt, size_t sz);
static int lcd5110WriteDatas(lcd_ctr_t * lcd, unsigned char *dt, size_t sz);
static int lcd5110WriteCmd(lcd_ctr_t *lcd, unsigned char dt);
static int lcdSetGPIO(lcd_ctr_t *lcd, unsigned int pin, unsigned int val);
static void lcd5110SetAddrMode(lcd_ctr_t * lcd, unsigned char verticalMode);
///////////////////////
//   Pin Fuctions    //
///////////////////////
static int lcdSetGPIO(lcd_ctr_t *lcd, unsigned int pin, unsigned int val)
{
	lcd->data.values[pin] = val;
	int ret = ioctl(lcd->gpio_req.fd, GPIOHANDLE_SET_LINE_VALUES_IOCTL, &lcd->data);
	if(ret < 0){
		perror(strerror(errno));
		return -1;
	}
	return 0;
}

static int lcdGPIOInit(lcd_ctr_t * lcd)
{
	int devid;
	ASSERT("[lcd_gpio - open]",devid = open(LCD5110_GPIO_DEV_PATH, O_RDONLY));
	lcd->gpio_req.flags = GPIOHANDLE_REQUEST_OUTPUT;
	lcd->gpio_req.lines = 3;
	lcd->LCD_DC = 0;
	lcd->LCD_RST = 1;
	lcd->LCD_BKLIGHT = 2;

	lcd->gpio_req.lineoffsets[lcd->LCD_DC] = LCD5110_DC_PIN;
	lcd->gpio_req.lineoffsets[lcd->LCD_RST] =  LCD5110_RESET_PIN;
	//lcd->gpio_req.lineoffsets[lcd->LCD_BKLIGHT] = LCD5110_LED_PIN;
	lcd->gpio_req.default_values[lcd->LCD_DC] = 0;
	lcd->gpio_req.default_values[lcd->LCD_RST] = 0;
	//lcd->gpio_req.default_values[lcd->LCD_BKLIGHT] = 0;

	int res;
	ASSERT("[lcd_gpio - ioctl]", res = ioctl(devid, GPIO_GET_LINEHANDLE_IOCTL, &lcd->gpio_req));
	close(devid);

	return 0;
}

static int lcdSPIInit(lcd_ctr_t * lcd)
{
	int fd;
	ASSERT("[lcdSPI - open]", fd = open(LCD5110_SPI_DEV_PATH, O_RDWR));
	lcd->spiid = fd;
	return 0;
}

/*------------------------------------------------ 
* lcd5110Init 
* Init the 5110 LCD
* Paras:
*  >> : 
*  >> : 
* Return: 
*  >> 
* Change Records: 
*  >> (29/08/2020): Create the function 
*----------------------------------------------*/
int lcd5110Init(lcd_ctr_t *lcd)
{
	memset(lcd, 0, sizeof(lcd_ctr_t));
	ASSERT("[lcd - init]", lcdGPIOInit(lcd));
	ASSERT("[lcd - init]", lcdSPIInit(lcd));
	//sce1();
	RES(lcd, 1);
	usleep(100000);
	RES(lcd, 0);
	usleep(100000);
	RES(lcd, 1);
	
	lcd5110SetBias(lcd, 2);
	lcd5110SetContrast(lcd, 0x40);
	lcd5110WriteCmd(lcd, PCD8544_DISPLAYCONTROL | PCD8544_DISPLAYNORMAL);
	//sce1();
	//BKLED(lcd, 1);
	//init the font system
	lcd->font = &font_6x8_;
	return 0;
}

/*------------------------------------------------ 
* lcd5110WriteCmd
* Write a byte into lcd, command or data. 
* Paras:
*  >> : 
*  >> : 
* Return: 
*  >> 
* Change Records: 
*  >> (29/08/2020): Create the function 
*----------------------------------------------*/
static int lcd5110WriteCmd(lcd_ctr_t *lcd, unsigned char dt)
{
	DC(lcd, 0);		
	return lcd5110WriteDatasRaw(lcd, &dt, 1);
}

static int lcd5110WriteDatas(lcd_ctr_t *lcd, unsigned char *dt, size_t sz){
	DC(lcd, 1);
	return lcd5110WriteDatasRaw(lcd, dt, sz);
}

static int lcd5110WriteDatasRaw(lcd_ctr_t * lcd, unsigned char *dt, size_t sz)
{
	memset(&lcd->xfer, 0, sizeof(lcd->xfer));
	lcd->xfer.tx_buf = (unsigned long long)dt;
	lcd->xfer.len = sz;
	lcd->xfer.tx_nbits = 8;
	lcd->xfer.speed_hz = 4000000;

	int ret;
	ASSERT("[lcdSPI - ioctl]",ret = ioctl(lcd->spiid, SPI_IOC_MESSAGE(1), &lcd->xfer));
	//ASSERT("[lcdSPI - write]", ret = write(lcd->spiid, &dt, sz));
	return 0;
}

/*------------------------------------------------ 
* lcd5110Update
* Update the lcd 5110 screen. 
* Paras:
*  >> : 
*  >> : 
* Return: 
*  >> 
* Change Records: 
*  >> (29/08/2020): Create the function 
*----------------------------------------------*/
void lcd5110Update(lcd_ctr_t *lcd ){
	uint8_t x, y;
	uint8_t * data = &(lcd->lcdCache[0][0]);
	lcd5110SetXy(lcd, 0,0);
	lcd5110SetAddrMode(lcd, 1);
	lcd5110WriteDatas(lcd,data,LCD_X_RES*LCD_Y_RES/8);
}

/*------------------------------------------------ 
* Lcd5110SetXy 
* Set the origin of lcd. 
* Paras:
*  >> : 
*  >> : 
* Return: 
*  >> 
* Change Records: 
*  >> (29/08/2020): Create the function 
*----------------------------------------------*/
static void lcd5110SetXy(lcd_ctr_t *lcd, unsigned char X,unsigned char Y)
{
	lcd5110WriteCmd(lcd, PCD8544_SETYADDR | Y);// column
	lcd5110WriteCmd(lcd, PCD8544_SETXADDR | X);// row
}


void lcd5110SetBias(lcd_ctr_t * lcd, unsigned char val)
{
	if (val > 0x07) {
		val = 0x07;
	}
	lcd5110WriteCmd(lcd, PCD8544_FUNCTIONSET | PCD8544_EXTENDEDINSTRUCTION);
	lcd5110WriteCmd(lcd, PCD8544_SETBIAS | val);
	lcd5110WriteCmd(lcd, PCD8544_FUNCTIONSET);
}


void lcd5110SetContrast(lcd_ctr_t * lcd, unsigned char val)
{
	if(val > 0x7f) val = 0x7f;
	lcd5110WriteCmd(lcd, PCD8544_FUNCTIONSET | PCD8544_EXTENDEDINSTRUCTION);
	lcd5110WriteCmd(lcd, PCD8544_SETVOP | val);
	lcd5110WriteCmd(lcd, PCD8544_FUNCTIONSET);
}


static void lcd5110SetAddrMode(lcd_ctr_t * lcd, unsigned char verticalMode)
{
	unsigned char cmd = PCD8544_FUNCTIONSET;
	if(verticalMode) cmd |= PCD8544_VERTICAL_MODE;
	lcd5110WriteCmd(lcd, cmd);
}
