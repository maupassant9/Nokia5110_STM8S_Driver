
/* 
* FileName: 
* Author: Dong Xia 
* This is head file of 
* 
* Change Records: 
*      >> (13/05/2021): Creation of file 
* 
*/

#ifndef  _XG_H_
#define _XG_H_
/********************************************
* Include 
********************************************/
/********************************************
* Macro 
********************************************/


/********************************************
* Type definition 
********************************************/
typedef unsigned int uint32_t;
typedef unsigned short uint16_t;
typedef unsigned char uint8_t;
typedef signed int int32_t;
typedef signed short int16_t;
typedef signed char int8_t;

typedef struct {
    uint16_t x;
    uint16_t y;
}XG_Pos_t;

typedef XG_Pos_t XG_Sz_t;

typedef struct{
    unsigned char * font;
    XG_Sz_t fontSz;
} XG_Font_t;

/********************************************
* Function prototype 
********************************************/

#endif
